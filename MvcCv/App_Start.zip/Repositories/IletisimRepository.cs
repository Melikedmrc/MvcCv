﻿using MvcCv.Models.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcCv.Repositories
{
    public class IletisimRepository : GenericRepository <TblIletisim>
    {
    }
}